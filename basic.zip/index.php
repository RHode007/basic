<?php

include 'web/index.php';

echo ('its');